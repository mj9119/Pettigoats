$(document).ready(function() {
	$('#featured_slide_').s3Slider({
		timeOut:6000 
	});
});